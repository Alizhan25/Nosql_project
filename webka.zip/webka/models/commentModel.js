const mongoose = require('mongoose');
const schema = new mongoose.Schema({
    post_id: {
        type: mongoose.SchemaTypes.ObjectID,
        required: true
    },
    commentator: {
        type: mongoose.SchemaTypes.ObjectID,
        required: true
    },
    send_time: {
        type: Date,
        immutable: true,
        default: () => Date.now()
    },
    text: {
        type: String,
        required: true
    }
});
const comment = new mongoose.model('comments', schema);
module.exports = comment;