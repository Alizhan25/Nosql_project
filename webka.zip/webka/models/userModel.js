const mongoose = require('mongoose');
const schema = new mongoose.Schema({
    email: {
        type: String,
        required: true,
        unique: true
    },
    name: {
        type: String,
        default: 'user',
    },
    password: {
        type: String,
        required: true
    },
    description: {
        type: String,
        default: ""
    },
    posts: {
        type: [mongoose.SchemaTypes.ObjectID]
    },
    chats: {
        type: [mongoose.SchemaTypes.ObjectID]
    },
    createdAt: {
        type: Date,
        immutable: true,
        default: () => Date.now()
    },
    updatedAt: {
        type: Date
    },
    roles: [{type: String, ref: 'Role'}]
});

schema.pre('save', function(next){
    this.updatedAt = Date.now()
    next()
})
module.exports = new mongoose.model('users', schema);
// module.exports = user;