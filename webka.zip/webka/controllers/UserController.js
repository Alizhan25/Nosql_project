const UserModel = require('../models/userModel');
const Role = require('../models/roleModel');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const {secret} = require("../config/config")
const path = require('path')

const generateAccessToken = (id, roles) => {
    const payload = {
        id,
        roles
    }
    return jwt.sign(payload, secret, {expiresIn: "24h"} )
}

// Create and Save a new user
exports.create = async (req, res) => {
    if (!req.body.email && !req.body.name && !req.body.password) {
        res.status(400).send({ message: "Content can not be empty!" });
    }

    const {name, email, password} = req.body;

    const candidate = await UserModel.findOne({email: email})
    if (candidate) {
        res.status(400).json({message: "Пользователь с таким именем уже существует"})
    }

    const hashPassword = bcrypt.hashSync(password, 7);
    const userRole = await Role.findOne({value: "user"})
    const user = new UserModel({name: name, password: hashPassword, email: email, roles: ["user"]});
    await user.save().then(data => {
        // res.send({
        //     message:"User created successfully!!",
        //     user:data
        // });
        res.redirect('/users/' + data._id)
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while creating user"
        });
    });
};
// login
exports.login = async (req, res) => {
    try {
        const {email, password} = req.body
        const user = await UserModel.findOne({email})
        if (!user) {
            res.status(400).json({message: `Пользователь ${email} не найден`})
        }
        const validPassword = bcrypt.compareSync(password, user.password)
        if (!validPassword) {
            res.status(400).json({message: `Введен неверный пароль`})
        }
        const token = generateAccessToken(user._id, user.roles)
        res.redirect('/users/' + user._id)
        // res.json({token})
    } catch (e) {
        console.log(e)
        res.status(400).json({message: 'Login error'})
    }
}
// Retrieve all users from the database.
exports.findAll = async (req, res) => {
    try {
        const user = await UserModel.find();
        res.render(path.resolve("views/users.ejs"),{
            data: user
        })
    } catch(error) {
        res.status(404).json({message: error.message});
    }
};
// Find a single User with an id
exports.findById = async (req, res) => {
    try {
        const user = await UserModel.findById(req.params.id);
        res.render(path.resolve("views/profile.ejs"),{
            user: user
        })
    } catch(error) {
        res.status(404).json({ message: error.message});
    }
};
// Update a user by the id in the request
exports.updateById = async (req, res) => {
    if(!req.body) {
        res.status(400).send({
            message: "Data to update can not be empty!"
        });
    }

    const id = req.params.id;

    await UserModel.findByIdAndUpdate(id, req.body, { useFindAndModify: false }).then(data => {
        if (!data) {
            res.status(404).send({
                message: `User not found.`
            });
        }else{
            res.send({ message: "User updated successfully." })
        }
    }).catch(err => {
        res.status(500).send({
            message: err.message
        });
    });
};
// Delete a user with the specified id in the request
exports.destroyById = async (req, res) => {
    await UserModel.findByIdAndRemove(req.params.id).then(data => {
        if (!data) {
            res.status(404).send({
                message: `User not found.`
            });
        } else {
            res.send({
                message: "User deleted successfully!"
            });
        }
    }).catch(err => {
        res.status(500).send({
            message: err.message
        });
    });
};