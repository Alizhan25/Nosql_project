const PostModel = require('../models/postModel')
const UserModel = require("../models/userModel");
const bcrypt = require("bcryptjs");
const Role = require("../models/roleModel");
// Create and Save new post
exports.create = async (req, res) => {
    if (!req.body.title && !req.body.text) {
        res.status(400).send({ message: "Content can not be empty!" });
    }

    const {title, } = req.body;

    const candidate = await UserModel.findOne({email: email})
    if (candidate) {
        return res.status(400).json({message: "Пользователь с таким именем уже существует"})
    }

    const hashPassword = bcrypt.hashSync(password, 7);
    const userRole = await Role.findOne({value: "user"})
    const user = new UserModel({name: name, password: hashPassword, email: email, roles: ["user"]});
    await user.save().then(data => {
        // res.send({
        //     message:"User created successfully!!",
        //     user:data
        // });
        // res.redirect('/users/' + data._id)
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while creating user"
        });
    });
};
// Find all posts
exports.findAll = async (req, res) => {};
// Find post by id
exports.findById = async (req, res) => {};
// Find post by author
exports.findByAuthor = async (req, res) => {};
// Update a post by the id in the request
exports.updateById = async (req, res) => {};
// Delete a post with the specified id in the request
exports.deleteById = async (req, res) => {};