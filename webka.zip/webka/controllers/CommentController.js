const CommentModel = require('../models/commentModel')
// Create and Save new message
exports.create = async (req, res) => {};
// Find all messages
exports.findAll = async (req, res) => {};
// Find message by id
exports.findById = async (req, res) => {};
// Find message by author
exports.findByCommentator = async (req, res) => {};
// Update a message by the id in the request
exports.updateById = async (req, res) => {};
// Delete a message with the specified id in the request
exports.deleteById = async (req, res) => {};