const express = require('express')
const app = express();
let port = process.env.PORT;
if (port == null || port === "") {
    port = 3000;
}

app.set('view engine', 'ejs')
app.use(express.static('public'));

const swaggerUi = require("swagger-ui-express")
swaggerDocument = require("./swagger.json")
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

// mongoose database
const mongoose = require('mongoose')
const db = require('./config/databaseConfig')
mongoose.connect(db.url,
    () => {
    console.log('Connected')
    },e => console.error("error:" + e)
)

// for reading data
app.use(express.urlencoded({extended: true}))

// routes
app.use("/", require("./routes/main"));
app.use("/index", require("./routes/index"));
app.use("/main", require("./routes/main"));
app.use("/users", require("./routes/users"));
app.use("/posts", require("./routes/posts"));
app.use("/profile", require("./routes/profile"));
app.use("/about", require("./routes/about"));
app.use("/register", require("./routes/register"));
app.use("/login", require("./routes/login"));

app.use("/category", require("./routes/category"));
app.use("/single", require("./routes/single"));







// how to create new objects
// const User = require('./models/userModel');
// async function run() {
//     try {
//         // const user = new User({email: "Sam1@gmail.com", name: "Sam1", password: "Sam1"})
//         const user = await User.findOne({email: "Sam1@gmail.com"})
//         // console.log(user)
//         user.posts[0] = '627c0d08a50cc831ee7fb568'
//         console.log(user)
//         await user.save()
//         console.log(user)
//     } catch (e) {
//         console.log(e.message)
//     }
//     // const user = await User.create({email: "Sam4@gmail.com", name: "Sam3", password: "Sam4"})
//     // user.name = "Sam4"
//
// }
//
// run();

// heroku:  https://thawing-journey-04013.herokuapp.com/ | https://git.heroku.com/thawing-journey-04013.git
// "host": "thawing-journey-04013.herokuapp.com",


app.listen(port, () =>
    console.log(`App listening at http://localhost:${port}`)
);