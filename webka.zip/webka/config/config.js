module.exports = {
    secret: "SECRET_KEY_RANDOM"
}