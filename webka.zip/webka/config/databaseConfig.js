module.exports = {
    // url: 'mongodb://localhost:27017/RickDB'
    url: "mongodb+srv://Rick:Rick@cluster0.c3wnc.mongodb.net/myFirstDatabase?retryWrites=true"
}