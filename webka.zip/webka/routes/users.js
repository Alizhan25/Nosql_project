const express = require('express')
const userController = require('../controllers/UserController')
const router = express.Router();

router.get('/', userController.findAll);
router.get('/:id', userController.findById);
router.post('/', userController.create);
router.post('/login', userController.login);
router.patch('/:id', userController.updateById);
router.delete('/:id', userController.destroyById);

module.exports = router