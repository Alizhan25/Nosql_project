const express = require("express");
const router = express.Router();
const Post = require('../models/postModel');

router.get('/',async (req, res) => {
    const posts = await Post.find({})
    res.render('posts', {
        title: 'Posts page',
        posts
    })
})

module.exports = router;