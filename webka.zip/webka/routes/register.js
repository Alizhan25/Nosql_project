const express = require("express");
const User = require("../models/userModel");
const router = express.Router();

router
    .route('/')
    .get((req, res) => {
        res.render('register', {
            title: 'Register page'
        })
    })

router.post('/createUser',async (req, res) => {
    const user = new User({
        email: req.body.email,
        name: req.body.name,
        password: req.body.password
    })
    await user.save()
    res.redirect('/users')
})

module.exports = router;