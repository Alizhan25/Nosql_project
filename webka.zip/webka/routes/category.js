const express = require("express");
const router = express.Router();

router.get('/',(req, res) => {
    res.render('category', {
        title: 'category page'
    })
})

module.exports = router;